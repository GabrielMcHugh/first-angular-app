export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAufzhMeYGmISJ_r49lvFMmsGzZ6R4l2KU",
    authDomain: "oshop-d82a6.firebaseapp.com",
    projectId: "oshop-d82a6",
    storageBucket: "oshop-d82a6.appspot.com",
    messagingSenderId: "690517248702",
    appId: "1:690517248702:web:18a4efb3592c2276e16cef"
  },
};
